package com.cg.ticketmanagementsystem.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component("technician")
@Scope("prototype")
public class Technician {
	
    private String technicianName;
	private String technicianCategory;
	private Contact contact;
    private List<Ticket>ticket;
	public Technician() {
		super();
		
	}
	public Technician(String technicianName, String technicianCategory, Contact contact, List<Ticket> ticket) {
		super();
		this.technicianName = technicianName;
		this.technicianCategory = technicianCategory;
		this.contact = contact;
		this.ticket = ticket;
	}
	public String getTechnicianName() {
		return technicianName;
	}
	public void setTechnicianName(String technicianName) {
		this.technicianName = technicianName;
	}
	public  String getTechnicianCategory() {
		return technicianCategory;
	}
	public void setTechnicianCategory(String technicianCategory) {
		this.technicianCategory = technicianCategory;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public List<Ticket> getTicket() {
		return ticket;
	}
	public void setTicket(List<Ticket> ticket) {
		this.ticket = ticket;
	}
	@Override
	public String toString() {
		return "Technician [technicianName=" + technicianName + ", technicianCategory=" + technicianCategory
				+ ", contact=" + contact + ", ticket=" + ticket + "]";
	}
}