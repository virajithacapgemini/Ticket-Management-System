package com.cg.ticketmanagementsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ticketmanagementsystem.dao.TechnicianDao;
import com.cg.ticketmanagementsystem.dao.TechnicianDaoImpl;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
@Service("service")
public class TechnicianServiceImpl implements TechnicianService {
    @Autowired
	TechnicianDao dao;

	/*public TechnicianServiceImpl() {
		
	}
*/
	/**In the save method it will save details of techniciancategory and contact details 
	 ** throws CategoryNotFoundException*/
	public Technician add(Technician technician) {
		
		
		return dao.save(technician);
	}
	
	/**In findtechnicianbycategory on searching particular technician category it displays technicianname and categoryname*/
	public List<Technician> searchTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> technicians=dao.findTechnicianByCategory(techniciancategory);
		if(technicians.isEmpty())
			throw new CategoryNotFoundException("category does not exist.......");
		return technicians;
	}
	
	/**In showall method it displays all the technician categories that are  saved in database*/
	public List<Technician> showAlltechniciancategory() {
		return dao.showAlltechniciancategory();
	}

}
