package com.cg.ticketmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
@Repository
public class TechnicianDaoImpl implements TechnicianDao {

	public static List<Technician> techniciandata= new ArrayList<Technician>();

	// List<Technician> techniciancategory;
	//public TechnicianDaoImpl() {
		//techniciandata = new ArrayList<Technician>();
		// techniciancategory=new ArrayList<Technician>();
	
	/**In the save method it will save details of techniciancategory and contact details 
	 ** throws CategoryNotFoundException*/
	public Technician save(Technician technician) {
		
		techniciandata.add(technician);
		return technician;
		
	}
	
	/**In findtechnicianbycategory on searching particular technician category it displays technicianname and categoryname*/

	public List<Technician> findTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> tcsearch = new ArrayList();
		for (Technician technician : techniciandata) {
			if (technician.getTechnicianCategory().equals(techniciancategory))
				tcsearch.add(technician);
			
		}

		return tcsearch;
	}
	/**In showall method it displays all the technician categories that are  saved in database*/
	public List<Technician> showAlltechniciancategory() {
		return techniciandata;
	}

}
