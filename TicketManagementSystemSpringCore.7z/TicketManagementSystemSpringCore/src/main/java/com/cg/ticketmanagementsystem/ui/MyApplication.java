package com.cg.ticketmanagementsystem.ui;

import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.demoonespringcore.congif.JavaConfig;
import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.service.TechnicianService;
import com.cg.ticketmanagementsystem.service.TechnicianServiceImpl;
import com.cg.ticketmanagementsystem.service.TicketService;
import com.cg.ticketmanagementsystem.service.TicketServiceImpl;

@Component
public class MyApplication {
	static TechnicianService service;
	static TicketService ticketservice;
	@Autowired
	TechnicianService techservice;
	@Autowired
	TicketService tservice;
	@PostConstruct
	public void init() {
		service=this.techservice;
		ticketservice=this.tservice;
	}
	
public static void main(String args[]) {
		
		AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class)	;
		Technician technician=null;
	    Ticket ticket=(Ticket) app.getBean ("ticket");
         // List<Ticket> tickets;
		
		 Scanner sc=new Scanner(System.in);
		 int choice=0;
		 do {
			   print();
				System.out.println("enter choice");
				choice=sc.nextInt();
				switch(choice) {
				case 1:
					//add technician
					//Technician technician=(Technician) app.getBean("technician");	
					System.out.println("enter technician category");
					String techniciancategory=sc.next();
					System.out.println("enter technician name");
					String technicianname=sc.next();
					System.out.println("enter contact emailid");
					String emailid=sc.next();
					System.out.println("enter contact mobilenumber");
					BigInteger mobilenumber=sc.nextBigInteger();
					//Technician technicianone=new Technician();
					technician=(Technician) app.getBean("technician");
					technician.setTechnicianCategory(techniciancategory);
					technician.setTechnicianName(technicianname);
					 Contact contact=(Contact) app.getBean("contact");
					contact.setEmailId(emailid);
					contact.setMobileNumber(mobilenumber);
					//technician.setContact(contact);
					service.add(technician);
					System.out.println("technician details added.......");
					break;
				case 2://assigning
					// Ticket ticket=(Ticket) app.getBean ("ticket");
					System.out.println("enter ticket id  ");
				    int id= sc.nextInt();
				    System.out.println("enter categoryname  ");
				    String categoryname=sc.next();
				    System.out.println("enter compliant  ");
				    String compliant=sc.next();
				  
				    System.out.println("enter posted date");
					  String addDate=sc.next();
					  SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
					  Date date=null;
					  try {
						  date=sdf.parse(addDate);
					  }catch(ParseException e) {
						  System.out.println("Date " + addDate+ " is not valid according to "+((SimpleDateFormat)sdf).toPattern() + "pattern.");
					  }
					ticket.setId(id);
				    ticket.setCategoryName(categoryname);
				    ticket.setCompliant(compliant);
				    ticket.setPostedDate(date);
				   //ticketservice.assignTicket(ticket, technician);
				    try {
				    	ticket= ticketservice.assignTicket(ticket, technician);
				    	//System.out.println(ticketservice.toString());
				    	 ticket.setStatus("Technician assigned");
				    	System.out.println(ticket.getStatus());
				    }
				    catch(CategoryNotFoundException e) {
				    	System.out.println(e.getMessage());
				    }
				    
				    
				break;	
				
				case 3:
					//show all technician category
					List<Technician> mylist=service.showAlltechniciancategory();
					for(Technician techniciandata:mylist) {
						System.out.println("technician category "+techniciandata.getTechnicianCategory());
					}
					break;
					
				case 4://search technician category
					System.out.println("enter technician category");
					String techcsearch=sc.next();
					//List<Technician> tcsearch=null;
					try 
					{
						List<Technician> tcsearch=null;
						tcsearch=service.searchTechnicianByCategory(techcsearch);
						for(Technician technician1:tcsearch) {
							System.out.println("technician category : "  +technician1.getTechnicianCategory()); 
							System.out.println("technician name : "  +technician1.getTechnicianName());
						}
					}catch(CategoryNotFoundException e) {
						System.out.println(e.getMessage());
					}
						break;
							
				case 5://search by id
					System.out.println("enter ticket id");
					int ticketid=sc.nextInt();
					//List<Ticket> tidsearch=null;
					Ticket tidsearch=null;
					try
					{
						tidsearch=ticketservice.searchticketBytId(ticketid);
					if(tidsearch!=null) {
							System.out.println("ticket id " +tidsearch.getId());
							System.out.println("category name " +tidsearch.getCategoryName());
							System.out.println("complaint " +tidsearch.getCompliant());
						
						
						
						}
						
					}
					catch(CategoryNotFoundException e) {
						System.out.println(e.getMessage());}
				
				break;
					
		 }
		 }while(choice!=6);  
	}
		 
	private static void print() {
		// TODO Auto-generated method stub
		System.out.println("1.Add Technician");
		System.out.println("2.AssignTicket");
		System.out.println("3.show all technician categories");
		System.out.println("4.search technician by category");
		System.out.println("5.search ticket by id");
	}
	
}

