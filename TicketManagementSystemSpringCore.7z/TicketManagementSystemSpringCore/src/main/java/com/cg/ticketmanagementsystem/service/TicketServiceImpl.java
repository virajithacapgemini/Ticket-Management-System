package com.cg.ticketmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ticketmanagementsystem.dao.TechnicianDaoImpl;
import com.cg.ticketmanagementsystem.dao.TicketDaoImpl;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
@Service("ticketservice")
public class TicketServiceImpl implements TicketService{
	@Autowired
	TicketDaoImpl dao;

	/*public TicketServiceImpl() {
		super();
		
	}*/
	
	/**In save ticket method if the technician category and ticket category are matched then technician will assign if not throws
	 * CategoryNotFoundException */
	public Ticket assignTicket(Ticket ticket, Technician technician) throws CategoryNotFoundException {
		
	return dao.save(ticket);
			
}

	/** In this findbyid it displays particular details of that ticket complaint,categoryname*/
	public Ticket searchticketBytId(int id) throws CategoryNotFoundException {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}
	