package com.cg.ticketmanagementsystem.exception;

public class CategoryNotFoundException extends Exception{
	
	public CategoryNotFoundException() {
		super();
	}
	
	public CategoryNotFoundException(String s) {
      super(s);
}
}