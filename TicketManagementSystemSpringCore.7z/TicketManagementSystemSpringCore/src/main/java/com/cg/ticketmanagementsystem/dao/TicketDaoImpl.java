package com.cg.ticketmanagementsystem.dao;

import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
@Repository
public class TicketDaoImpl implements TicketDao{
	
	List<Ticket> ticketdata=new ArrayList<Ticket>();
	//public TicketDaoImpl() {
		//ticketdata=new ArrayList<Ticket>();
		
	
	/**In save ticket method if the technician category and ticket category are matched then technician will assign if not throws
	 * CategoryNotFoundException */
	 
	public Ticket save(Ticket ticket) throws CategoryNotFoundException  {
		
		for(Technician t : TechnicianDaoImpl.techniciandata) {
			if(t.getTechnicianCategory().equals(ticket.getCategoryName()))
			{
				ticketdata.add(ticket);
				return ticket;
			}
		}

	throw new CategoryNotFoundException("category not found");
	}

	
	/** In this findbyid it displays particular details of that ticket complaint,categoryname*/
	public Ticket findById(int id)throws CategoryNotFoundException{
		//System.out.println(ticketdata);
		for(Ticket ticket:ticketdata) 
		if(ticket.getId()==id)
		return ticket;
		throw new CategoryNotFoundException("TicketId not found");
		
	}
	
}






