package com.cg.ticketmanagementsystem.dao;

import java.util.List;


import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public interface TicketDao {
	public Ticket save(Ticket ticket) throws CategoryNotFoundException;
	
	
	public Ticket findById(int id) throws CategoryNotFoundException;
}
