package com.cg.ticketmanagementsystem.dto;

import java.math.BigInteger;

public class Contact {
	private String emailId;
	private BigInteger mobileNumber;
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String emailId, BigInteger mobileNumber) {
		super();
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public BigInteger getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(BigInteger mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "Contact [emailId=" + emailId + ", mobileNumber=" + mobileNumber + "]";
	}
}