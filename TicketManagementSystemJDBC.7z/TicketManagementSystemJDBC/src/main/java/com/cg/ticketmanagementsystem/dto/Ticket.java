package com.cg.ticketmanagementsystem.dto;

import java.util.Date;

public class Ticket {
	private int id;
	private String categoryName;
	private String compliant;
	private String status;
	private Date postedDate;
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
		
	}
	
	


	public Ticket(int id, String categoryName, String compliant, String status, Date postedDate) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.compliant = compliant;
		this.status = status;
		this.postedDate = postedDate;
	}




	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public String getCompliant() {
		return compliant;
	}


	public void setCompliant(String compliant) {
		this.compliant = compliant;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	public Date getPostedDate() {
	return postedDate;
}


public void setPostedDate(Date postedDate) {
	this.postedDate = postedDate;
}




@Override
public String toString() {
	return "Ticket [id=" + id + ", categoryName=" + categoryName + ", compliant=" + compliant + ", status=" + status
			+ ", postedDate=" + postedDate + "]";
}



	


	/*public Date getPostedDate() {
		return postedDate;
	}


	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}*/


	
}


