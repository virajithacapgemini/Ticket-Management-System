package com.cg.ticketmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ticketmanagementsystem.dao.TechnicianDaoImpl;
import com.cg.ticketmanagementsystem.dao.TicketDaoImpl;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public class TicketServiceImpl implements TicketService{
	
	TicketDaoImpl dao;

	public TicketServiceImpl() {
		super();
		dao=new  TicketDaoImpl();
	}
	

	public Ticket assignTicket(Ticket ticket, Technician technician) throws CategoryNotFoundException {
		
		
		return dao.save(ticket,technician);
			
}


	public Ticket searchtickeBytId(int id) throws CategoryNotFoundException {
		// TODO Auto-generated method stub
		
		
		return dao.findById(id);
		
		
	}

}
	/*public List<Ticket> searchByticketId(int id) throws CategoryNotFoundException{
		// TODO Auto-generated method stub
		return dao.findById(id);
	}
	*/
	/*public Ticket searchticketById(int id) throws CategoryNotFoundException{
		// TODO Auto-generated method stub
		return dao.findById(id);
	}


}
*/