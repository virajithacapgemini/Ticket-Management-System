package com.cg.ticketmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.util.DBUtil;


public class TechnicianDaoImpl implements TechnicianDao {

	Connection conn=null;
	PreparedStatement pstm=null;
	ResultSet result=null;
	public Technician save(Technician technician) {
		//Technician tech=new Technician();
	// Contact contact=new Contact();
		if(technician.getContact()!=null) {
		try {
			conn=DBUtil.getConnection();
		}catch(CategoryNotFoundException e) {
			e.printStackTrace();
		
		}
		Contact con=technician.getContact();
		try {
			String query=("insert into contact(emailid,mobilenumber)values(?,?)");
			pstm=conn.prepareStatement(query);
			pstm.setString(1, con.getEmailId());
			pstm.setString(2, con.getMobileNumber().toString());
			 pstm.executeUpdate();
			 
			pstm=conn.prepareStatement("insert into technician(techniciancategory,technicianname,emailid) values(?,?,?)");
			pstm.setString(1, technician.getTechnicianCategory());
			pstm.setString(2, technician.getTechnicianName());
			pstm.setString(3, technician.getContact().getEmailId());
			pstm.executeUpdate();
			
			// result=pstm.executeUpdate();
			//int res=pstm.executeUpdate();
			
			/*if(res>0) {
				pstm=conn.prepareStatement("select max(technicianid) from technician");
				int technicianid=0;
				//pstm=conn.prepareStatement(query);
				result=pstm.executeQuery();
				if(result.next()) {
					technicianid=result.getInt(1);
				}*/
				/*String query=("insert into contact(emailid,mobilenumber)values(?,?)");
				pstm=conn.prepareStatement(query);
				pstm.setString(1, technician.getContact().getEmailId());
				pstm.setString(2, contact.getMobileNumber().toString());
				 pstm.executeUpdate();*/
				//pstm=conn.prepareStatement(query);
				//pstm.executeQuery();
				//if(res>0)
					//return technician;
				
				
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				
				pstm.close();
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		}
		return technician;
	}

	public List<Technician> findTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> tcsearch = new ArrayList();
		PreparedStatement pstm=null;
		Connection conn=DBUtil.getConnection();
		try{
			pstm=conn.prepareStatement("select technicianname,techniciancategory  from technician where techniciancategory=?");
			pstm.setString(1, techniciancategory);
			ResultSet rs=pstm.executeQuery();
			while(rs.next()) {
					Technician tech=new Technician();
					tech.setTechnicianName(rs.getString(1));
					tech.setTechnicianCategory(rs.getString(2));
					tcsearch.add(tech);
				//Technician technician=findtechnicianByCategory(rs.getInt(1));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		
	} 
		return tcsearch;
	}

	public List<Technician> showAlltechniciancategory() throws CategoryNotFoundException {
		PreparedStatement pstm=null;
		Connection conn=DBUtil.getConnection();
		List<Technician> mylist = new ArrayList();
		try {
			String query="select techniciancategory from technician";
			pstm=conn.prepareStatement(query);
			ResultSet result=pstm.executeQuery();
			while(result.next()) {
				Technician tech=new Technician();
				tech.setTechnicianCategory(result.getString(1));
				//mylist=add(tech);
				mylist.add(tech);
			}
				
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				conn.close();
				pstm.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
	
		}
		return mylist;
	}

	

	/*public static List<Technician> techniciandata;

	// List<Technician> techniciancategory;
	public TechnicianDaoImpl() {
		techniciandata = new ArrayList<Technician>();
		// techniciancategory=new ArrayList<Technician>();
	}

	public Technician save(Technician technician) {
        
		techniciandata.add(technician);
		return technician;
		// return save(technician);
	}

	public List<Technician> findByTechnicianCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> tcsearch = new ArrayList();
		for (Technician technician : techniciandata) {
			if (technician.getTechnicianCategory().equals(techniciancategory))
				tcsearch.add(technician);
			
		}
		if(tcsearch.isEmpty())
			throw new CategoryNotFoundException("techniciancategory not found exception");
		return tcsearch;
	}

	public List<Technician> showAlltechniciancategory() {
		return techniciandata;
	}
*/
		
}

	
