package com.cg.ticketmanagementsystem.service;

import java.util.List;

import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public interface TechnicianService {
	
	public Technician add(Technician technician);
	List<Technician> searchTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException;
	List<Technician> showAlltechniciancategory() throws CategoryNotFoundException;
	
}
