package com.cg.ticketmanagementsystem.dto;

import java.util.List;



public class Technician {
	
	private int technicianid;
    private String technicianName;
	private String technicianCategory;
	private Contact contact;
	private List<Ticket>ticket;
	public Technician() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Technician(int technicianid, String technicianName, String technicianCategory, Contact contact, List<Ticket> ticket) {
		super();
		this.technicianid = technicianid;
		this.technicianName = technicianName;
		this.technicianCategory = technicianCategory;
		this.contact = contact;
		this.ticket = ticket;
	}

	
	public int getTechnicianId() {
		return technicianid;
	}

	public void setId(int id) {
		this.technicianid = id;
	}

	public String getTechnicianName() {
		return technicianName;
	}
	public void setTechnicianName(String technicianName) {
		this.technicianName = technicianName;
	}
	public  String getTechnicianCategory() {
		return technicianCategory;
	}
	public void setTechnicianCategory(String technicianCategory) {
		this.technicianCategory = technicianCategory;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public List<Ticket> getTicket() {
		return ticket;
	}
	public void setTicket(List<Ticket> ticket) {
		this.ticket = ticket;
	}

	@Override
	public String toString() {
		return "Technician [id=" + technicianid + ", technicianName=" + technicianName + ", technicianCategory="
				+ technicianCategory + ", contact=" + contact + ", ticket=" + ticket + "]";
	}
	
}