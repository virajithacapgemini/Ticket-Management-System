package com.cg.ticketmanagementsystem.service;

import java.util.List;

import com.cg.ticketmanagementsystem.dao.TechnicianDao;
import com.cg.ticketmanagementsystem.dao.TechnicianDaoImpl;
import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public class TechnicianServiceImpl implements TechnicianService {

	private TechnicianDao dao;

	public TechnicianServiceImpl() {
		dao = new TechnicianDaoImpl();
	}

	public Technician add(Technician technician) {
		return dao.save(technician);
	}

	public List<Technician> searchTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> technicians=dao.findTechnicianByCategory(techniciancategory);
		if(technicians.isEmpty())
			throw new CategoryNotFoundException("...category not found...");
		return technicians;
	}

	public List<Technician> showAlltechniciancategory() throws CategoryNotFoundException{
		return dao.showAlltechniciancategory();
	}

}
