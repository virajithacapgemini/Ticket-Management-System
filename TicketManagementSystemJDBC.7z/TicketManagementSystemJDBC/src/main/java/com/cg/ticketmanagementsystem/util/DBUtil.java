package com.cg.ticketmanagementsystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public class DBUtil {
	static Connection conn;
	public static Connection getConnection() throws CategoryNotFoundException{
		Properties prop=new Properties();
		try {
			InputStream it=new FileInputStream("src/main/java/resources/jdbc.properties");
			prop.load(it);
			if(prop!=null) {
				String driver=prop.getProperty("jdbc.driver");
				String url=prop.getProperty("jdbc.url");
				String uname=prop.getProperty("jdbc.username");
				String upass=prop.getProperty("jdbc.password");
				Class.forName(driver);
				conn=DriverManager.getConnection(url,uname,upass);
			}
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
			throw new CategoryNotFoundException("file not found");
		}catch(IOException e) {
			e.printStackTrace();
			throw new CategoryNotFoundException("file not found");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			throw new CategoryNotFoundException("file not found");
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new CategoryNotFoundException("file not found");
		
	}
 return conn;
}
}