package com.cg.ticketmanagementsystem.service;

import java.util.List;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public interface TicketService {
	
	public Ticket assignTicket(Ticket ticket,Technician technician) throws CategoryNotFoundException;
	//List<Ticket> searchByticketId(int id) throws CategoryNotFoundException;

	Ticket searchtickeBytId(int id) throws CategoryNotFoundException;

}
