package com.cg.ticketmanagementsystem.dao;

import java.util.List;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public interface TicketDao {
	public Ticket save(Ticket ticket,Technician technician) throws CategoryNotFoundException;
	//List<Ticket> findById(int id) throws CategoryNotFoundException;
	
	Ticket findById(int id) throws CategoryNotFoundException;
}
