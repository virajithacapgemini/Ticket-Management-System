package com.cg.ticketmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.util.DBUtil;

public class TicketDaoImpl implements TicketDao{


	public Ticket save(Ticket ticket,Technician technician) throws CategoryNotFoundException {
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet result=null;
		int techid=0;
		try {
			conn=DBUtil.getConnection();
		}catch(CategoryNotFoundException e) {
			e.printStackTrace();
		
		}//String query="insert into ticket(technicianid,categoryname,compliant,status)values(?,?,?,?)";
  
		try {
			pstm=conn.prepareStatement("select technicianid from technician where techniciancategory=?");
			pstm.setString(1,ticket.getCategoryName());
			result=pstm.executeQuery();
			while(result.next()) {
				techid=result.getInt(1);
			}
			if(techid==0) {
				throw new CategoryNotFoundException("This category not found...");
			}
			String query="insert into ticket(technicianid,categoryname,compliant,status) values(?,?,?,?)";
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, techid);
			pstm.setString(2, ticket.getCategoryName());
		     pstm.setString(3, ticket.getCompliant());
		     pstm.setString(4, "Approved");
		     
		//pstm.setDate(5,ticket.getPostedDate());
			int res=pstm.executeUpdate();
			if(res>0)
				System.out.println("ticket assigned");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				
				pstm.close();
				conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	      return ticket;
		
	}
/*
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet result=null;
		try {
			pstm=conn.prepareStatement("select technicianid from technician where technicianid=?");*/
		
		
	public Ticket findById(int id) throws CategoryNotFoundException {
		List<Ticket> tidsearch = new ArrayList<Ticket>();
		PreparedStatement pstm=null;
		Connection conn=DBUtil.getConnection();
		Ticket ti=new Ticket();
		try{
			pstm=conn.prepareStatement("select id,categoryname,compliant  from ticket where id=?");
			pstm.setInt(1, id);
			ResultSet rs=pstm.executeQuery();
			while(rs.next()) {
					
					ti.setId(rs.getInt(1));
                    ti.setCategoryName(rs.getString(2));
                    ti.setCompliant(rs.getString(3));
					tidsearch.add(ti);
				//Technician technician=findtechnicianByCategory(rs.getInt(1));
			}
		}catch(SQLException e) {
			e.printStackTrace();
		
	} 
		return ti;
	}
		
		
	
	
	
}






