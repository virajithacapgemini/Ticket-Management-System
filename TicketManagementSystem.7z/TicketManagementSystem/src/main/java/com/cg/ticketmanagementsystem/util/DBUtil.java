package com.cg.ticketmanagementsystem.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.ticketmanagementsystem.dto.Technician;

public class DBUtil {
	public static List<Technician> tech=new ArrayList<Technician>();
	

}
