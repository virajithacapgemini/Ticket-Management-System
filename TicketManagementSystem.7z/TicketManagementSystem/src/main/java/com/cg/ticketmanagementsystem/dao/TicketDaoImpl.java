package com.cg.ticketmanagementsystem.dao;

import java.util.ArrayList;

import java.util.List;


import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public class TicketDaoImpl implements TicketDao{
	
	List<Ticket> ticketdata=new ArrayList<Ticket>();
	public TicketDaoImpl() {
		ticketdata=new ArrayList<Ticket>();
		
	}
	public Ticket save(Ticket ticket) throws CategoryNotFoundException  {
		
		for(Technician t : TechnicianDaoImpl.techniciandata) {
			if(t.getTechnicianCategory().equals(ticket.getCategoryName()))
			{
				ticketdata.add(ticket);
				return ticket;
			}
		}

		throw new CategoryNotFoundException("category not found");
	}

	/*public List<Ticket> findById(int id) throws CategoryNotFoundException{
		// TODO Auto-generated method stub
		List<Ticket> tidsearch=new ArrayList();
		for(Ticket ticket:ticketdata) {
			if(ticket.getTicketId()==(id)) {
				tidsearch.add(ticket);
				return tidsearch;

			}
		} throw new CategoryNotFoundException("ticketid not found exception");

	}
*/
	
	public Ticket findById(int id)throws CategoryNotFoundException{
		System.out.println(ticketdata);
		for(Ticket ticket:ticketdata) 
		if(ticket.getId()==id)
		return ticket;
		throw new CategoryNotFoundException("TicketId not found");
		
	}
	
}






