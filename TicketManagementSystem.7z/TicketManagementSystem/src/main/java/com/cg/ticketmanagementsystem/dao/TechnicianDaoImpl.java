package com.cg.ticketmanagementsystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;

public class TechnicianDaoImpl implements TechnicianDao {

	public static List<Technician> techniciandata;

	// List<Technician> techniciancategory;
	public TechnicianDaoImpl() {
		techniciandata = new ArrayList<Technician>();
		// techniciancategory=new ArrayList<Technician>();
	}

	public Technician save(Technician technician) {

		techniciandata.add(technician);
		return technician;
		// return save(technician);
	}

	public List<Technician> findByTechnicianCategory(String techniciancategory) throws CategoryNotFoundException {
		List<Technician> tcsearch = new ArrayList();
		for (Technician technician : techniciandata) {
			if (technician.getTechnicianCategory().equals(techniciancategory))
				tcsearch.add(technician);
			
		}
		if(tcsearch.isEmpty())
			throw new CategoryNotFoundException("techniciancategory not found exception");
		return tcsearch;
	}

	public List<Technician> showAlltechniciancategory() {
		return techniciandata;
	}

}
