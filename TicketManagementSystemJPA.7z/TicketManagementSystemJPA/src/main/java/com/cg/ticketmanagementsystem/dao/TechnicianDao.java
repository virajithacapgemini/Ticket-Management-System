package com.cg.ticketmanagementsystem.dao;

import java.util.List;

import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;


public interface TechnicianDao
{
	public Technician  save(Technician technician) throws CategoryNotFoundException;
	List<Technician> findTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException;
	public List<Technician> showAlltechniciancategory() throws CategoryNotFoundException;
	
}
