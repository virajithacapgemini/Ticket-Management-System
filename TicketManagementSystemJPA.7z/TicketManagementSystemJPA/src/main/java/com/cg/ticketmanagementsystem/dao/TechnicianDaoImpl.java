package com.cg.ticketmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.util.DBUtil;


public class TechnicianDaoImpl implements TechnicianDao {
	EntityManager em;

	public TechnicianDaoImpl() {
	em=DBUtil.getConnection();
	}
	/**In the save method it will save details of techniciancategory and contact details into the database
	 ** throws CategoryNotFoundException*/
	public Technician save(Technician technician)throws CategoryNotFoundException {
		em=DBUtil.getConnection();
		try {
		em.merge(technician);
		em.getTransaction().commit();
		return technician;
		}catch(Exception e) {
			throw new CategoryNotFoundException("technician category not added");
		}
		finally {
			if(em!=null) {
				em.close();
			}
		}
		
	}
	
	/**In findtechnicianbycategory on searching particular technician category it displays technicianname and categoryname*/
	public List<Technician> findTechnicianByCategory(String techniciancategory) throws CategoryNotFoundException {
		em=DBUtil.getConnection();
		
		String sql="select t from Technician t  where t.technicianCategory=:technicianCategory";
		TypedQuery<Technician> query=em.createQuery(sql,Technician.class);
		query.setParameter("technicianCategory", techniciancategory);
		List<Technician> tcsearch=query.getResultList();
		
		em.getTransaction().commit();
		return tcsearch;
	}
	
	/**In showall method it displays all the technician categories that are  saved in database*/
	public List<Technician> showAlltechniciancategory() throws CategoryNotFoundException {
		em=DBUtil.getConnection();
	  String qStr="SELECT tech FROM Technician tech ";
      TypedQuery<Technician> query=em.createQuery(qStr,Technician.class);
	  List<Technician> mylist=query.getResultList();
		return mylist;                       
	}
	

	
		
}

	
