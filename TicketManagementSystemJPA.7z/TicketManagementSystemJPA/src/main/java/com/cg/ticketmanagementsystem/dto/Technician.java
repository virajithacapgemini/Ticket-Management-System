package com.cg.ticketmanagementsystem.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="techniciandb")
public class Technician {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="technician_id")
	private int technicianid;
    @Column(name="technician_name")
    private String technicianName;
    @Column(name="technician_category")
	private String technicianCategory;
    @OneToOne(cascade=CascadeType.ALL)
	private Contact contact;
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="tech_id")
	private List<Ticket>ticket;
	public Technician() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	public Technician(int technicianid, String technicianName, String technicianCategory, Contact contact,
			List<Ticket> ticket) {
		super();
		this.technicianid = technicianid;
		this.technicianName = technicianName;
		this.technicianCategory = technicianCategory;
		this.contact = contact;
		this.ticket = ticket;
	}




	

	public int getTechnicianid() {
		return technicianid;
	}




	public void setTechnicianid(int technicianid) {
		this.technicianid = technicianid;
	}




	public String getTechnicianName() {
		return technicianName;
	}




	public void setTechnicianName(String technicianName) {
		this.technicianName = technicianName;
	}




	public String getTechnicianCategory() {
		return technicianCategory;
	}




	public void setTechnicianCategory(String technicianCategory) {
		this.technicianCategory = technicianCategory;
	}




	public Contact getContact() {
		return contact;
	}




	public void setContact(Contact contact) {
		this.contact = contact;
	}




	public List<Ticket> getTicket() {
		return ticket;
	}




	public void setTicket(List<Ticket> ticket) {
		this.ticket = ticket;
	}




	@Override
	public String toString() {
		return "Technician [id=" + technicianid + ", technicianName=" + technicianName + ", technicianCategory="
				+ technicianCategory + ", contact=" + contact + ", ticket=" + ticket + "]";
	}
	
}