package com.cg.ticketmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.util.DBUtil;

public class TicketDaoImpl implements TicketDao{
	
	
	EntityManager em;

	public TicketDaoImpl() {
	em=DBUtil.getConnection();
	} 
/**In save ticket method if the technician category and ticket category are matched then technician will assign if not throws
 * CategoryNotFoundException */
 
	public Ticket save(Ticket ticket) throws CategoryNotFoundException {
		try {
			em=DBUtil.getConnection();
			
			String sql="select t from Technician t where t.technicianCategory= :technicianCategory";
			TypedQuery<Technician> query=em.createQuery( sql,Technician.class);
		   query.setParameter("technicianCategory", ticket.getCategoryName());
		   Technician t=query.getSingleResult();
		   List<Ticket> tlist=t.getTicket();
		   tlist.add(ticket);
		   t.setTicket(tlist);
		   em.merge(t);
		   em.getTransaction().commit();
		   return ticket;
			
			
		}catch(Exception e) {
			  throw new CategoryNotFoundException("this category not found....");
		}
		
		
	}
	
/** In this findbyid it displays particular details of that ticket complaint,categoryname*/
	public Ticket findticketById(int id) throws CategoryNotFoundException {
		try {

		em=DBUtil.getConnection();
		String sql="select tic from Ticket tic  where tic.id=:id";
		TypedQuery<Ticket> query=em.createQuery(sql,Ticket.class);
		query.setParameter("id", id);
		Ticket tidsearch=query.getSingleResult();
		em.getTransaction().commit();
		return tidsearch;
		}catch(Exception e) {
			  throw new CategoryNotFoundException("this id not found....");
		}
		
	}


	
		
	
	
	
	
}






