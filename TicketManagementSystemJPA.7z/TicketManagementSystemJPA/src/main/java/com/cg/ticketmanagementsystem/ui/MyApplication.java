package com.cg.ticketmanagementsystem.ui;

import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.ticketmanagementsystem.dto.Contact;
import com.cg.ticketmanagementsystem.dto.Technician;
import com.cg.ticketmanagementsystem.dto.Ticket;
import com.cg.ticketmanagementsystem.exception.CategoryNotFoundException;
import com.cg.ticketmanagementsystem.service.TechnicianService;
import com.cg.ticketmanagementsystem.service.TechnicianServiceImpl;
import com.cg.ticketmanagementsystem.service.TicketService;
import com.cg.ticketmanagementsystem.service.TicketServiceImpl;

public class MyApplication {
	
	public static void main(String args[]) throws CategoryNotFoundException {
		
		 Technician technician=new Technician();
		 Ticket ticket=new Ticket();
		 TechnicianService service=new TechnicianServiceImpl();
		 TicketService ticketservice=new TicketServiceImpl();
		 List<Ticket> tickets;
		 
		 Contact contact;
		 Scanner sc=new Scanner(System.in);
		 int choice=0;
		 do {
			   print();
				System.out.println("enter choice");
				choice=sc.nextInt();
				switch(choice) {
				case 1:
					//add technician
					System.out.println("enter technician category");
					String techniciancategory=sc.next();
					System.out.println("enter technician name");
					String technicianname=sc.next();
					System.out.println("enter contact emailid");
					String emailid=sc.next();
					System.out.println("enter contact mobilenumber");
					BigInteger mobilenumber=sc.nextBigInteger();
					Technician technicianone=new Technician();
					technician.setTechnicianCategory(techniciancategory);
					technician.setTechnicianName(technicianname);
					contact=new Contact();
					contact.setEmailId(emailid);
					contact.setMobileNumber(mobilenumber);
					technician.setContact(contact);
					//service.add(new Technician(new Random().nextInt(100),technicianname, techniciancategory,contact,null));
					try {
						service.add(technician);     
					}catch(CategoryNotFoundException e) {
				    	System.out.println(e.getMessage());
					}
					System.out.println("technician details added");
					break;
					
				case 2://assigning
					//System.out.println("enter ticket id  ");
				   // int id= sc.nextInt();
				    System.out.println("enter categoryname  ");
				    String categoryname=sc.next();
				    System.out.println("enter compliant  ");
				    String compliant=sc.next();	
				  System.out.println("enter posted date");
				  String addDate=sc.next();
				  SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
				  Date date=null;
				  try {
					  date=sdf.parse(addDate);
				  }catch(ParseException e) {
					  System.out.println("Date" + addDate+ "is not valid according to"+((SimpleDateFormat)sdf).toPattern() + "pattern.");
				  }
				  
				   
				    ticket.setCategoryName(categoryname);
				    ticket.setCompliant(compliant);
				   // ticket.setStatus(status);
				   ticket.setPostedDate(date);
				    try {
				    	ticket= ticketservice.assignTicket(ticket, technician);
				    	//System.out.println(ticketservice.toString());
				    	 ticket.setStatus("Technician assigned");
				    	System.out.println(ticket.getStatus());
				    }
				    catch(CategoryNotFoundException e) {
				    	System.out.println(e.getMessage());
				    	
				    }
				    
				    
				break;	
				
				case 3:
					//show all technician category
					
					List<Technician> mylist=service.showAlltechniciancategory();
					
					for(Technician techniciandata:mylist) {
						
					//for(Technician tcsearch:mylist) {
						System.out.println("technician category "+ techniciandata.getTechnicianCategory());
						//System.out.println("technician name "+ techniciandata.getTechnicianName());
					}
					break;
					
				case 4://search technician category
					System.out.println("enter technician category");
					String techcsearch=sc.next();
					//List<Technician> tcsearch=null;
					try 
					{
						List<Technician> tcsearch=null;
						tcsearch=service.searchTechnicianByCategory(techcsearch);
						for(Technician technicianone1:tcsearch) {
							System.out.println("technician category : "  +technicianone1.getTechnicianCategory());
							System.out.println("technician name : "  +technicianone1.getTechnicianName());
						}
					}catch(CategoryNotFoundException e) {
						System.out.println(e.getMessage());
					}
						break;
							
				case 5://search by id
					System.out.println("enter ticket id");
					int ticketid=sc.nextInt();
					//List<Ticket> tidsearch=null;
					Ticket tidsearch=null;
					try
					{
						tidsearch=ticketservice.searchticketBytId(ticketid);
						
						if(tidsearch!=null) {
							System.out.println("ticket id " +tidsearch.getId());
							System.out.println("category name " +tidsearch.getCategoryName());
							System.out.println("complaint " +tidsearch.getCompliant());
						
						
						
						}
						
					}
					catch(CategoryNotFoundException e) {
						System.out.println(e.getMessage());}
				
				break;
					
		 }
		 }while(choice!=6);  
	}
		 
	private static void print() {
		// TODO Auto-generated method stub
		System.out.println("1.Add Technician");
		System.out.println("2.AssignTicket");
		System.out.println("3.show all technician categories");
		System.out.println("4.search technician by category");
		System.out.println("5.search ticket by id");
	}
	
}

