package com.cg.ticketmanagementsystem.query;

public interface Query {

}
